import subprocess

import os, math
import time
import operator
from flask import Flask,request,jsonify
import csv

app = Flask(__name__)


class AKTE_EaaS(object):
    
    def __init__(self):
        self.NumberOfRequests=0
        self.Number100=0
        self.Number200=0
        self.Number300=0
        self.Number400=0
        self.Number500=0

        self.NumberMachines=0
        self.Errors=0
        self.delta_T=1
        self.repair_c=0
        self.s=0
        self.PausedVMs=[]
        self.Experiment=open("Wiki.log","w")        
        self.u_estimate=0
        self.P_estimate=0
        self.sum500=0
        self.decisionCurrentCapacity=0
        
        
    def estimator(self,t,Delta_Load, sigma_Alive, AvgCapacity, D):
        self.Delta_Load=Delta_Load
        self.avg_n=float(sigma_Alive)/t#self.delta_T #t   
        self.u_estimate=float(AvgCapacity)/self.avg_n
        self.P_estimate=float(Delta_Load)/self.avg_n#tmath.ceil(self.delta_T) #math.ceil(self.delta_T) #
        if AvgCapacity!=0:
            self.delta_T=math.ceil(float(D)/AvgCapacity)
        else:
            self.delta_T=1
    
    def controller(self,delta_Time):
            self.R=self.u_estimate*self.P_estimate*self.avg_n
            if self.R<0:
                self.R=self.R/15
                print "Neg", self.R/2
            else:
                self.R=self.R/delta_Time
            print self.R/delta_Time
            

     
    def ProactiveRepair(self,Server_Speed,Load,delta_Time, CurrentCapacity):
        self.repair_c+=(self.R)
        Proactive=0
        self.PastMinute=0
        if  self.repair_c<0 :    
            self.s=int(self.repair_c)
            print self.s, "SSS", self.repair_c
            self.repair_c-=self.s    
            if CurrentCapacity+abs(self.s)>=math.ceil(self.NumberOfRequests/Server_Speed)+2 :
                self.decisionCurrentCapacity+=math.ceil(self.s)   #because when I scale down, no more requests go to the VMs to shut down.
                print>>self.Experiment, "in c"
                return -abs(self.s)
            elif self.s<0:
                    self.decisionCurrentCapacity=math.ceil(self.NumberOfRequests/Server_Speed)+2
                    print>>self.Experiment, "in b"
                    return -abs(int(math.ceil(monitor.NumberMachines-self.decisionCurrentCapacity)))-1
        elif self.repair_c>=1 :
            Proactive=int(self.repair_c)
            print self.repair_c,"----------",Proactive 
            self.repair_c-=Proactive 
             
            return Proactive
            
    def ReactRepair(self,Load,delta_Time, CurrentCapacity, proactive):
        TemporaryVariable=math.ceil(Load)-CurrentCapacity+2
        if proactive!=None:
                   
            if float(Load)>CurrentCapacity :
                if  TemporaryVariable>proactive:
                    TemporaryVariable-=proactive    
                elif TemporaryVariable<proactive:
                    TemporaryVariable=proactive
                return TemporaryVariable
            else:
                return proactive
        else:
            return TemporaryVariable
    
             

             



@app.route('/AKTE/v1.0/monitoring', methods=['POST'])
def run_AKTE():
    global t2,Time_Previous,Time_lastEstimation,CapacityList,GammaTime,sigma_Alive
    t1=time.time()
    t=t2-t1
#     monitor.startMonitoring()
#    time.sleep(10)
    #print self.JobsList
    Server_Speed=float(request.json['server_speed'])
    Current_Time=time.time()
    try:
        CurrentCapacity=float(request.json['capacity'])
    except:
        pass
    Current_Load=float(request.json['load_requests'])
    try:
        Current_CPULoad=request.json['load_CPU']
        Current_MemoryLoad=request.json['load_memory']
    except:
        print("There are no CPU/memory metrics")
    D=0.01*CurrentCapacity  
    LoadServers=int(math.ceil(float(Current_Load)/Server_Speed))
#             print Load
    #print Load
    delta_Time=Current_Time-Time_Previous
    Time_Previous=Current_Time          
    x=Current_Time-Time_lastEstimation           
    CapacityList+=[(CurrentCapacity,delta_Time)]
    tempCapac=0
    t1=time.time()

    if Current_Time-GammaTime>=math.ceil(monitor.delta_T):   # To be revised, Why 500 !
        for i in CapacityList:
#                        print i[0],i[1],self.AvgCapacity,Current_Time,GammaTime
                tempCapac+=i[0]*i[1]
                AvgCapacity=float(tempCapac)/(Current_Time-GammaTime)   
        PreviousCapacity=CurrentCapacity
        GammaTime=Current_Time
        CapacityList=[]
    if x>=monitor.delta_T:  
#         print "Load", LoadServers, "Capacity",CurrentCapacity  
        Delta_Load=LoadServers-CurrentCapacity
        t_calc=Current_Time-initial_Time
        monitor.estimator(t_calc,Delta_Load, sigma_Alive, AvgCapacity, D)
        monitor.controller(delta_Time)        
        Time_lastEstimation=Current_Time
        Previous_Load=Current_Load
    proactive=monitor.ProactiveRepair(Server_Speed,LoadServers,delta_Time,CurrentCapacity)
    results=monitor.ReactRepair(LoadServers, delta_Time, CurrentCapacity, proactive)
    sigma_Alive+=CurrentCapacity
    t2=time.time()
    with open("./ResultsAKTE.csv", "a") as csv_file:
                    writer=csv.writer(csv_file,delimiter=',')    
                    writer.writerow([LoadServers, CurrentCapacity, Server_Speed,Current_Load, t2-t1])            
        
    return jsonify({'prediction': results}), 201

if __name__ == '__main__':
    GammaTime=0
    PreviousCapacity=0
    Time=0
    Previous_Load=0
    Time_Previous=time.time()
    initial_Time=Time_Previous
    delta_Time=1
    GammaTime=Time_Previous
    Delta_Load=0
    CapacityList=[] 
    monitor=AKTE_EaaS() 
    CurrentCapacity=1
    sigma_Alive=1
    PreviousTime=time.time()
    Time_lastEstimation=time.time()
    t2=time.time()
    app.run(debug=True, host='127.0.0.1', port=5012, use_reloader=False)
    run_AKTE()
