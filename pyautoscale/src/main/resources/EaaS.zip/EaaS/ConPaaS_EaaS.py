import subprocess

import os, math
import time
import operator
from flask import Flask,request,jsonify
import csv


import numpy as nump

from counter import Counter
from prediction_models import Prediction_Models
from performance import StatUtils

app = Flask(__name__)


class ConPaaS_EaaS(object):
    
    def __init__(self,ID=None):
        self.NumberOfRequests=0
        self.performance_predictor = Prediction_Models()
        self.stat_utils = StatUtils()
        self.p=0
        self.NumberMachines=0
        self.Errors=0
        self.delta_T=1
        self.repair_c=0
        self.s=0
        self.PausedVMs=[]
        self.Experiment=open("Wiki.log","w")        
        self.u_estimate=0
        self.P_estimate=0
        self.sum500=0
        self.decisionCurrentCapacity=0
        self.forecast_req_rate_model_selected = 0
        self.forecast_req_rate_predicted = 0
        self.forecast_list_req_rate = {}
        
    def prediction_evaluation(self, req_rate_data):
            data_req_rate_filtered = req_rate_data
           
            async_result_req_ar = self.performance_predictor.auto_regression(data_req_rate_filtered, 20)
            async_result_req_lr = self.performance_predictor.linear_regression(data_req_rate_filtered, 20)
            async_result_req_exp_smoothing = self.performance_predictor.exponential_smoothing(data_req_rate_filtered, 2)

            self.forecast_list_req_rate[1] = async_result_req_lr
            self.forecast_list_req_rate[2] = async_result_req_exp_smoothing
            self.forecast_list_req_rate[0] = async_result_req_ar
            #  self.forecast_list_req_rate[0] = async_result_req_arma.get()


#             try:
#             print "Getting the forecast request rate for the best model in the previous iteration " + str(self.forecast_req_rate_model_selected)
            weight_avg_predictions = self.stat_utils.compute_weight_average(self.forecast_list_req_rate[self.forecast_req_rate_model_selected])

#             if weight_avg_predictions > 0:
            self.forecast_req_rate_predicted = weight_avg_predictions
            
#             print "Prediction request rate for model " + str(self.forecast_req_rate_model_selected) + "--  Prediction req. rate: " + str(self.forecast_req_rate_predicted)
            return weight_avg_predictions
#             except Exception as e:
#                 print "Warning trying to predict a future value for the model." + str(e)

        

    def get_req_rate_prediction(self):
        return self.forecast_req_rate_predicted
             

             



@app.route('/ConPaaS/v1.0/monitoring', methods=['POST'])
def run_ConPaaS():
    global t2,LoadServers,Time_Previous,Time_lastEstimation,CapacityList
    t1=time.time()
    t=t2-t1
#     monitor.startMonitoring()
#    time.sleep(10)
    #print self.JobsList
    Server_Speed=float(request.json['server_speed'])
    Current_Time=time.time()
    try:
        CurrentCapacity=float(request.json['capacity'])
    except:
        pass
    Current_Load=float(request.json['load_requests'])
    try:
        Current_CPULoad=request.json['load_CPU']
        Current_MemoryLoad=request.json['load_memory']
    except:
        print("There are no CPU/memory metrics")

    LoadTotalServers=int(math.ceil(float(Current_Load)/Server_Speed))
    LoadServers+=[Current_Load]
#             print Load
    #print Load
    delta_Time=Current_Time-Time_Previous
    Time_Previous=Current_Time          
    x=Current_Time-Time_lastEstimation           
    CapacityList+=[(CurrentCapacity,delta_Time)]
    tempCapac=0
    t1=time.time()

    if len(LoadServers)<21:
                Predicted=math.ceil(Current_Load/float(Server_Speed))
    else:
                if Current_Load>Server_Speed:
                    Predicted=math.ceil(monitor.prediction_evaluation(LoadServers)/Server_Speed)
                    if Predicted==0 or Predicted==None:
                        Predicted=math.ceil(CurrentCapacity)
                else:
                    Predicted=1
                LoadServers.pop(0)
            
            
    t2=time.time()
    t2=time.time()
    with open("./ResultsConPaaS.csv", "a") as csv_file:
                    writer=csv.writer(csv_file,delimiter=',')    
                    writer.writerow([LoadTotalServers, CurrentCapacity, Server_Speed,Current_Load, t2-t1, Predicted])            
        
    return jsonify({'prediction': Predicted-CurrentCapacity}), 201

if __name__ == '__main__':
    LoadServers=[]
    Time_Previous=time.time()
    initial_Time=Time_Previous
    delta_Time=1
    GammaTime=Time_Previous
    Delta_Load=0
    CapacityList=[] 
    monitor=ConPaaS_EaaS() 
    CurrentCapacity=1
    sigma_Alive=1
    PreviousTime=time.time()
    Time_lastEstimation=time.time()
    t2=time.time()
    app.run(debug=True, host='127.0.0.1', port=5012, use_reloader=False)
    run_ConPaaS()
