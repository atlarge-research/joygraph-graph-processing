import subprocess

import os, math
import time
import operator
from flask import Flask,request,jsonify
import csv
from datetime import *

app = Flask(__name__)


class Hist_EaaS(object):
    
    def __init__(self):
        self.NumberOfRequests=0
        self.Number100=0
        self.Number200=0
        self.ErrorPasthrs=[]
        self.Number300=0
        self.Number400=0
        self.Number500=0
        self.histogram={}
        for i in range(24):
            self.histogram[i]=[]
        self.NumberMachines=0
        self.Errors=0
        self.delta_T=1
        self.repair_c=0
        self.s=0
        self.PausedVMs=[]
        self.Experiment=open("Wiki.log","w")        
        self.u_estimate=0
        self.P_estimate=0
        self.sum500=0
        self.decisionCurrentCapacity=0
        
        
    def maxPeriod(self,l, n):
        return [max(l[i:i+n]) for i in range(0, len(l), n)]
    
    #Adding the Estimator and the controller functionality

    def estimator(self,hr):
        Error=0
        if len(self.ErrorPasthrs)==7200:
            Error=sum(self.ErrorPasthrs)/7200
            self.ErrorPasthrs=self.ErrorPasthrs[3600:]
        predictor=self.histogram[hr]
        predictor.sort()
        
        try:
            precentile=predictor[int(len(predictor)*0.9)]
            return precentile+Error-self.CurrentCapacity
        except:
            return Error
#        print>>self.outTime,"ahmed", self.PastMinute

    
    def Hist_Repair(self,Load, CurrentCapacity):     
        TemporaryVariable=Load+2
        if Load>CurrentCapacity:
            return TemporaryVariable
            
#        print>>self.outTime,"heba", self.PastMinute

            
#     def ReactRepair(self,Load,delta_Time, CurrentCapacity):
#         TemporaryVariable=Load-CurrentCapacity
#         FutureMinute=TemporaryVariable
#         if TemporaryVariable>=0 :
#             return TemporaryVariable+2         
#         elif TemporaryVariable<-2 :
#              return TemporaryVariable+2  
             

             



@app.route('/Hist/v1.0/monitoring', methods=['POST'])
def run_Hist():
    global t2,Time_Previous,Time_lastEstimation,CapacityList,GammaTime,sigma_Alive,ErrorPasthrs
#     monitor.startMonitoring()
#    time.sleep(10)
    #print self.JobsList
    Server_Speed=float(request.json['server_speed'])
    try:
        CurrentCapacity=float(request.json['capacity'])
        monitor.CurrentCapacity=CurrentCapacity
    except:
        pass
    Current_Load=float(request.json['load_requests'])
    try:
        Current_CPULoad=request.json['load_CPU']
        Current_MemoryLoad=request.json['load_memory']
    except:
        print("There are no CPU/memory metrics")
    LoadServers=int(math.ceil(float(Current_Load)/Server_Speed))
    monitor.ErrorPasthrs+=[CurrentCapacity-LoadServers]
#             print Load
    #print Load
    monitor.ErrorPasthrs+=[monitor.CurrentCapacity-LoadServers]
    hr=datetime.now().hour
    monitor.histogram[hr]+=[LoadServers]
    results=monitor.estimator(hr)
    counter=0
    for i in monitor.ErrorPasthrs[-10:]:
                if i<0:
                    counter+=1
    if counter>5:
                results+=monitor.Hist_Repair(LoadServers, CurrentCapacity)
                monitor.ErrorPasthrs=[]   
    with open("./HistReact.csv", "a") as csv_file:
                    writer=csv.writer(csv_file,delimiter=',')    
                    writer.writerow([LoadServers, CurrentCapacity, Server_Speed,Current_Load, hr])            
        
    return jsonify({'prediction': results}), 201

if __name__ == '__main__':
    GammaTime=0
    PreviousCapacity=0
    Time=0
    Previous_Load=0
    delta_Time=1
    Delta_Load=0
    CapacityList=[] 
    monitor=Hist_EaaS() 
    CurrentCapacity=1
    sigma_Alive=1
    app.run(debug=True, host='127.0.0.1', port=5012, use_reloader=False)
    ErrorPasthrs=[]
    run_Hist()
