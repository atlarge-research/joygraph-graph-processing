import subprocess

import os, math
import time
import operator
from flask import Flask,request,jsonify
import csv
import numpy

app = Flask(__name__)


class Reg_EaaS(object):
    
    def __init__(self):
        self.NumberOfRequests=0
        self.Number100=0
        self.Number200=0
        self.Number300=0
        self.Number400=0
        self.Number500=0
        
        self.p=0
        self.NumberMachines=0
        self.Errors=0
        self.delta_T=1
        self.repair_c=0
        self.s=0
        self.PausedVMs=[]
        self.Experiment=open("Wiki.log","w")        
        self.u_estimate=0
        self.P_estimate=0
        self.sum500=0
        self.decisionCurrentCapacity=0
        self.PastMinute=0
        
    def estimator(self,Time,CurrentCapacity):
#        variance=numpy.std(self.RegressionProactiveLoad)
#         if math.ceil(self.p(Time))>0:
#            r=random.normalvariate(0,variance)
            self.PastMinute=math.ceil(self.p(Time))
#            print>>self.outTime,"ah",self.PastMinute,self.CurrentCapacity,self.p(Time)
#             if self.PastMinute<CurrentCapacity:
#                 self.PastMinute=CurrentCapacity
#             elif self.PastMinute>0:
#                 pass
            
            return math.ceil(self.PastMinute)
                



@app.route('/Reg/v1.0/monitoring', methods=['POST'])
def run_Reg():
    global t2,RegressionProactiveLoad,Time_Previous,Time_lastEstimation,CapacityList,RegressionListX, monitor
    t1=time.time()
    t=t2-t1
#     monitor.startMonitoring()
#    time.sleep(10)
    #print self.JobsList
    Server_Speed=float(request.json['server_speed'])
    Current_Time=time.time()
    try:
        CurrentCapacity=float(request.json['capacity'])
    except:
        pass
    Current_Load=float(request.json['load_requests'])
    try:
        Current_CPULoad=request.json['load_CPU']
        Current_MemoryLoad=request.json['load_memory']
    except:
        print("There are no CPU/memory metrics")

    LoadServers=int(math.ceil(float(Current_Load)/Server_Speed))
#             print Load
    #print Load
    delta_Time=Current_Time-Time_Previous
    Time_Previous=Current_Time          
    x=Current_Time-Time_lastEstimation           
    CapacityList+=[(CurrentCapacity,delta_Time)]
    tempCapac=0
    t1=time.time()

    RegressionProactiveLoad+=[LoadServers] 
    RegressionListX+=[Current_Time]
    if (CurrentCapacity>LoadServers):
        monitor.p = numpy.poly1d(numpy.polyfit(RegressionListX[-72:], RegressionProactiveLoad[-72:], deg=2))
        results=monitor.estimator(Current_Time,CurrentCapacity)
        print "res  ", results
        if results>CurrentCapacity:
            results=0
    else:
        results=LoadServers
    t2=time.time()
    t2=time.time()
    with open("./ResultsREG.csv", "a") as csv_file:
                    writer=csv.writer(csv_file,delimiter=',')    
                    writer.writerow([LoadServers, CurrentCapacity, Server_Speed,Current_Load, t2-t1, results])            
        
    return jsonify({'prediction': results-CurrentCapacity}), 201

if __name__ == '__main__':
    RegressionProactiveLoad=[]
    RegressionListX=[]
    Time_Previous=time.time()
    initial_Time=Time_Previous
    delta_Time=1
    GammaTime=Time_Previous
    Delta_Load=0
    CapacityList=[] 
    monitor=Reg_EaaS() 
    CurrentCapacity=1
    sigma_Alive=1
    PreviousTime=time.time()
    Time_lastEstimation=time.time()
    t2=time.time()
    app.run(debug=True, host='127.0.0.1', port=5012, use_reloader=False)
    run_Reg()
